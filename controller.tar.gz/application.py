from controller import *


def main():
    controller = Controller()
    controller.start()


if __name__ == '__main__':
    main()
