from datetime import date
import view
import events


class Controller:

    def __init__(self):
        self.view = view.View()

    def start(self):

        is_working = True

        while is_working:
            self.view.print_main_menu()
            choice = self.view.get_choice()
            try:
                if choice not in ["1", "2", "3", "0"]:
                    raise ValueError
                elif choice == "1":
                    self.book_event(PrivateMentoring())
                elif choice == "2":
                    self.book_event(Checkpoint())
                elif choice == "3":
                    self.print_all_events()
                elif choice == "0":
                    is_working = False
            except ValueError:
                self.view.print_message("Wrong number.")

        self.say_goodbye()

    def print_all_events(self):

        self.view.print_all_events(events.Event.get_events())

    def book_event(self, event):
        try:
            date = self.view.get_input("Enter the date (dd-mm-yyyy): ")
            date = self.__class__.convert_date(date)
        except ValueError:
            self.view.print_message("Invalid date string")
        events.event(date)
        if event == PrivateMentoring():
            event.preffered_mentor = self.view.get_input("Enter preffered mentor: ")
            event.goal = self.view.get_input("Enter your goal: ")

    def say_goodbye(self):

        self.view.print_goodbye()

    @staticmethod
    def convert_date(date_str):

        date_list = date_str.split("-")

        return date(int(date_list[2]), int(date_list[1]), int(date_list[0]))
